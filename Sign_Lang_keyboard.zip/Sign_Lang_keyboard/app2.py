from flask import Flask, request, jsonify, send_from_directory

app = Flask(__name__)

# Store the latest word
latest_word = ""

@app.route('/send_word', methods=['POST'])
def receive_word():
    global latest_word
    data = request.get_json()
    latest_word = data.get('word', '')
    # Optionally, broadcast the word to other devices (e.g., using WebSockets)
    return jsonify({"status": "success"}), 200

@app.route('/get_word', methods=['GET'])
def get_word():
    return jsonify({"latest_word": latest_word}), 200

@app.route('/')
def index():
    return send_from_directory('static', 'index2.html')

@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory('static', filename)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000)